# EET 核心基因、参考系统与种子序列

## 1. 使用原则

下列序列用于建立初始种子库，不是最终 HMM 训练集。

正确流程：

```text
实验验证或高可信种子
        ↓
每个家族分别 BLAST 扩展
        ↓
结构域、基序、定位和基因邻域确认
        ↓
高可信序列去冗余
        ↓
每个家族分别建立 HMM
```

一个 HMM 的建模单位是：

```text
一个蛋白家族
```

而不是一个物种。多个物种中的 MtrA 一起组成 `mtrA_verified.faa`，再建立 `mtrA.hmm`。

---

## 2. Shewanella oneidensis MR-1：经典 Mtr 型 EET

| 基因 | 参考编号 | 主要功能 | 注意事项 |
|---|---|---|---|
| `cymA` | UniProt `Q8E8S0` | 内膜醌池向周质传递电子 | NapC/NirT 近缘蛋白很多 |
| `cctA` | UniProt `Q8EDL6` | 周质四血红素细胞色素 | 约 100–120 aa，4 个 CXXCH |
| `mtrB` | UniProt `Q8CVD4` | 外膜 β 桶孔道 | 需和 MtrA/MtrC 邻域联合判断 |
| `mtrA` | UniProt `Q8EG35` | 周质十血红素细胞色素 | 约 333 aa，典型约 10 个 CXXCH |
| `mtrC` | UniProt `Q8EG34` | 胞外十血红素细胞色素 | 大型多血红素蛋白 |
| `omcA` | UniProt `Q8EG33` | 外膜/胞外多血红素细胞色素 | 与 MtrC/MtrF 近缘 |
| `mtrF` | UniProt `Q8EG32` | MtrC 旁系同源蛋白 | 单独建库 |
| `mtrE` | UniProt `Q8EG31` | MtrB 样孔道蛋白 | 单独建库 |
| `mtrD` | UniProt `Q8EG30` | MtrA 样多血红素蛋白 | 不能混入 MtrA |
| `dmsE` | UniProt `Q8EH05` | DmsE/MtrA 近缘蛋白 | 单独保存为近缘家族 |

### MtrA 和 CctA 的关键区别

| 特征 | MtrA | CctA |
|---|---|---|
| 长度 | 通常约 300–400 aa | 通常约 100–130 aa |
| CXXCH 数量 | 典型约 10 | 典型 4 |
| 作用 | Mtr 跨膜复合物中的周质电子传递 | 小型周质四血红素电子载体 |
| 是否能混建 HMM | 否 | 否 |

本次对话中发现的典型错误是：将大量约 100–120 aa、4 个 CXXCH 的 CctA/cytochrome c3 序列误当作 MtrA。低 E-value 不能修正错误的种子分类。

---

## 3. Geobacter sulfurreducens PCA：Geobacter 型 EET

建议按模块分别建库。

### 3.1 内膜电子输入

```text
imcH
cbcL
cbcA
cbcB
```

已讨论种子：

| 基因 | 编号 |
|---|---|
| `imcH` | UniProt `Q747K6` |

### 3.2 周质电子传递

```text
ppcA
ppcB
ppcC
ppcD
ppcE
```

初期可以先建：

```text
ppcABCDE_family.hmm
```

因为 PpcA-E 相近，分别建 HMM 可能互相命中。后期有足够多高可信序列时再细分。

参考信息：

| 基因 | 参考 |
|---|---|
| `ppcA` | locus tag `GSU0612`；对话中曾提到 NCBI 蛋白 `AAR33943` |

### 3.3 外膜 porin-cytochrome 系统

```text
ombB – omaB – omcB
ombC – omaC – omcC
extA – extB – extC – extD
extE – extF – extG
extH – extI – extJ – extK – extL
```

这类蛋白必须按复合物完整性和基因邻域判断。

### 3.4 胞外多血红素蛋白和导电结构

| 基因 | 已讨论 UniProt | 说明 |
|---|---|---|
| `omcS` | `Q74A86` | 胞外多血红素细胞色素 |
| `omcZ` | `Q74BG5` | 与电极生物膜 EET 密切相关 |
| `omcE` | `Q74FJ0` | 扩展基因 |
| `pilA-N` | `Q74D23` | 只能作为辅助证据 |

`pilA` 广泛参与运动、黏附、DNA 摄取和菌毛装配，不能单独作为 EET 标志。

---

## 4. Pio 型光合 Fe(II) 氧化

参考物种：

```text
Rhodopseudomonas palustris TIE-1
```

核心操纵子：

```text
pioB – pioA – pioC
```

种子：

| 基因 | UniProt |
|---|---|
| `pioA` | `A1EBT2` |
| `pioB` | `A1EBT3` |
| `pioC` | `A1EBT4` |

`PioA` 与 `MtrA/MtoA/DmsE` 近缘，不能仅靠 BLAST 名称分类。

---

## 5. Mto 型中性 Fe(II) 氧化

参考物种：

```text
Sideroxydans lithotrophicus ES-1
```

核心：

```text
mtoB – mtoA – mtoD
```

种子：

| 基因 | 编号 |
|---|---|
| `mtoA` | UniProt `D5CMQ0`；RefSeq `WP_013030620.1` |
| `mtoD` | UniProt `D5CN26` |

`MtoA` 与 MtrA/PioA/DmsE 高度接近，必须依赖邻域和系统发育树。

---

## 6. Cyc2/Rus 型铁氧化

参考物种：

```text
Acidithiobacillus ferrooxidans ATCC 23270
```

种子：

| 基因 | 编号 |
|---|---|
| `cyc2` | UniProt `B7JAQ7` |
| `rus` | UniProt `B7JAQ0`；RefSeq `WP_012537622.1` |

酸性铁氧化菌中可结合：

```text
cyc2 + cyc1 + rus
```

但不同类群中的 `cyc2` 邻域并不完全相同。

---

## 7. 革兰氏阳性菌黄素型 EET

参考物种：

```text
Listeria monocytogenes 10403S
```

建议检查整个功能位点：

```text
fmnA
fmnB
pplA
ndh2
eetA
eetB
dmkA
dmkB
```

已讨论种子：

| 基因 | UniProt |
|---|---|
| `fmnB` | `A0A0H3GJF7` |

注意：

- `FmnB/ApbE` 类蛋白不只存在于 EET 系统。
- `ndh2` 也不是 EET 特异基因。
- 高可信判断需要多个组件共存。

---

## 8. 古菌 EET

参考物种：

```text
Methanosarcina acetivorans C2A
```

核心候选：

```text
mmcA
```

建议单独建立古菌 EET 子库。

---

## 9. 吩嗪介导型 EET

参考物种：

```text
Pseudomonas aeruginosa PAO1
```

主要基因：

```text
phzA1-G1
phzA2-G2
phzM
phzS
phzH
```

已讨论的 UniProt：

```text
Q9HWH1  phzA1
Q9I2J9  phzA2
Q9HWH2  phzM
```

吩嗪介导 EET 并非 Fe 专属，建议放到独立目录：

```text
mediated_EET/phenazine/
```

---

## 10. 推荐种子目录

```text
EET_seed/
├── mtrA_seed.faa
├── mtrB_seed.faa
├── mtrC_seed.faa
├── mtrD_seed.faa
├── mtrE_seed.faa
├── mtrF_seed.faa
├── omcA_seed.faa
├── cymA_seed.faa
├── cctA_seed.faa
├── omcS_seed.faa
├── omcZ_seed.faa
├── pioA_seed.faa
├── pioB_seed.faa
├── pioC_seed.faa
├── mtoA_seed.faa
├── mtoB_seed.faa
├── mtoD_seed.faa
├── cyc2_seed.faa
├── rus_seed.faa
├── pplA_seed.faa
├── fmnB_seed.faa
├── mmcA_seed.faa
└── close_homologs/
    ├── dmsE_seed.faa
    ├── mtrD_seed.faa
    ├── mtoA_seed.faa
    └── pioA_seed.faa
```

---

## 11. 不建议作为独立 EET 阳性标志的基因

下面这些可以作为通路背景，但单独命中不能判定 EET：

```text
ccmABCDEFGH
pilB / pilC / pilD
tonB / exbB / exbD
feoA / feoB
普通 cytochrome c
普通 NADH dehydrogenase
普通 quinone oxidoreductase
coxABC
petABC
ferritin
```

## 12. 编号使用注意

本文件只汇总了对话中已明确讨论的编号。正式建库前，建议再次核对每个 accession 的：

```text
蛋白名称
参考物种/菌株
蛋白长度
locus tag
是否为 reviewed 条目
对应基因邻域
```

不要仅凭 accession 列表直接认定功能。
