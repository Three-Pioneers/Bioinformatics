# 宏基因组 Fe/EET 功能基因筛选总流程

## 1. 分析目标

宏基因组中的 Fe/EET 结果建议分成四类：

1. **Fe-EET**
   - 直接参与 Fe(III) 还原或 Fe(II) 氧化的胞外电子传递系统。
   - 例如 `mtrCAB`、`pioABC`、`mtoAB(D)`、`cyc2-rus`。

2. **非 Fe 专属 EET**
   - 能向电极、腐殖质、黄素或其他胞外受体传递电子，但不能仅凭基因证明一定参与铁循环。
   - 例如部分 `omcS/omcZ`、黄素型 EET、吩嗪介导型 EET。

3. **Fe 相关但非 EET**
   - 铁摄取、铁储存、铁载体和铁稳态相关基因。
   - 例如 `feoAB`、`fep/fec/fhu`、`fur`、ferritin、bacterioferritin。

4. **不确定候选**
   - 只有单个非特异基因，或蛋白结构正确但基因邻域因 contig 断裂而不完整。

因此，不建议使用：

```text
FeGenie 未命中 → 删除全部 EET 候选
```

更合理的是并行分析：

```text
                         宏基因组蛋白
                              │
                 ┌────────────┴────────────┐
                 │                         │
             FeGenie                  EET 专用库/HMM
                 │                         │
             Fe 功能候选                 EET 候选
                 └────────────┬────────────┘
                              │
                 结构域、定位、邻域和 MAG 综合判断
                              │
              Fe-EET / 非 Fe-EET / Fe 非 EET / 不确定
```

---

## 2. 推荐总流程

```text
Clean Reads
    ↓
MEGAHIT 组装
    ↓
Prodigal 预测 ORF 和蛋白
    ↓
├── FeGenie：Fe 氧化、Fe 还原、摄取、储存、调控等
└── EET 专用 BLAST/HMM：Mtr、Omc、Pio、Mto、Cyc2、黄素型等
    ↓
长度、完整性、保守基序、结构域、信号肽、膜拓扑
    ↓
目标蛋白所在基因组和上下游基因检查
    ↓
MAG 分箱、分类和通路完整性分析
    ↓
Reads 回帖和基因/MAG 丰度计算
    ↓
按 A/B/C 可信度输出
```

---

## 3. 组装和蛋白预测

### 3.1 MEGAHIT

```bash
megahit \
  -1 clean_R1.fq.gz \
  -2 clean_R2.fq.gz \
  --presets meta-sensitive \
  --min-contig-len 1000 \
  -t 32 \
  -o 3.megahit
```

### 3.2 Prodigal

```bash
mkdir -p 4.prodigal

prodigal \
  -i 3.megahit/final.contigs.fa \
  -a 4.prodigal/proteins.faa \
  -d 4.prodigal/genes.fna \
  -o 4.prodigal/genes.gff \
  -p meta \
  -f gff \
  -m -q
```

主要输出：

- `proteins.faa`：用于 BLAST、HMMER、InterProScan、SignalP。
- `genes.fna`：用于基因丰度计算。
- `genes.gff`：用于宏基因组自身 contig 上的基因邻域检查。

---

## 4. FeGenie 的角色

FeGenie 主要用于铁循环和铁稳态相关功能的初筛，包括：

- Fe(II) 氧化
- Fe(III) 还原
- 铁摄取
- 铁载体合成与转运
- 铁储存
- 铁调控
- 血红素利用

建议直接输入 contig，以保留基因邻域信息：

```bash
mkdir -p fegenie_input
cp 3.megahit/final.contigs.fa fegenie_input/sample.fna

FeGenie.py \
  -bin_dir fegenie_input \
  -bin_ext fna \
  -out fegenie_out \
  -t 16
```

也可以输入蛋白：

```bash
mkdir -p fegenie_orfs
cp 4.prodigal/proteins.faa fegenie_orfs/sample.faa

FeGenie.py \
  -bin_dir fegenie_orfs \
  -bin_ext faa \
  -out fegenie_orf_out \
  --orfs \
  -t 16
```

下面这些属于 Fe 代谢，但不是 EET 的直接证据：

```text
feoA / feoB
fep / fec / fhu
tonB / exbB / exbD
fur
ferritin / bacterioferritin
铁载体相关基因
```

---

## 5. EET 专用筛选的主要系统

### 5.1 Shewanella 型 Mtr 系统

```text
醌池
  ↓
CymA
  ↓
周质细胞色素（CctA、MtrA 等）
  ↓
MtrB 外膜孔道
  ↓
MtrC / OmcA 胞外多血红素细胞色素
  ↓
Fe(III)、矿物、电极或其他胞外受体
```

核心模块：

```text
mtrB – mtrA – mtrC
```

相关蛋白：

```text
cymA
cctA
omcA
mtrD / mtrE / mtrF
```

### 5.2 Geobacter 型

需要综合：

- 内膜：`imcH`、`cbcL`、`cbcBA`
- 周质：`ppcA-E`
- 外膜通道：`omb-oma-omc`、`ext` 系统
- 胞外多血红素：`omcS`、`omcZ`、`omcE`
- 菌毛：`pilA-N` 只能作辅助证据

### 5.3 Pio 型光合 Fe(II) 氧化

```text
pioB – pioA – pioC
```

### 5.4 Mto 型中性 Fe(II) 氧化

```text
mtoB – mtoA – mtoD
```

### 5.5 Cyc2 / Rus 型 Fe(II) 氧化

酸性铁氧化菌中常见：

```text
cyc2
cyc1
rus
```

中性铁氧化菌中的 `cyc2` 邻域不一定包含 `rus`。

### 5.6 革兰氏阳性菌黄素型 EET

重点看多个组分共同存在：

```text
fmnB
pplA
ndh2
eetA
eetB
fmnA
dmkA / dmkB
```

单个 `fmnB` 或 `ndh2` 不能证明 EET。

### 5.7 古菌 EET

可单独建立古菌数据库，例如：

```text
mmcA
```

不要与细菌 Mtr/Omc 家族混在一个 HMM 中。

---

## 6. MAG 归属

只在整个宏基因组里发现一个 EET 基因，不能确定由哪个微生物携带。

推荐：

```text
MetaBAT2 / MaxBin2 / CONCOCT
        ↓
DAS Tool 整合
        ↓
CheckM2
        ↓
GTDB-Tk
        ↓
目标基因所在 contig → MAG → 分类 → 通路完整性
```

建议最终表格至少包含：

```text
sample
gene_id
gene_family
protein_accession
contig
MAG
taxonomy
protein_length
BLAST_identity
query_coverage
subject_coverage
HMM_score
domain
CXXCH_count
signal_peptide
membrane_topology
neighbor_genes
pathway_class
abundance
confidence
```

---

## 7. 丰度计算

```bash
coverm contig \
  -1 clean_R1.fq.gz \
  -2 clean_R2.fq.gz \
  -r 4.prodigal/genes.fna \
  --methods count mean covered_fraction \
  -t 16 \
  > gene_abundance.tsv
```

不同样本间比较时，应进行长度和测序深度标准化，例如 TPM。

---

## 8. 可信度分级

### A 级：高可信

```text
完整蛋白
+ 结构域正确
+ 基序/定位正确
+ 关键邻域或完整通路存在
+ 基因组/MAG 归属明确
```

### B 级：中等可信

```text
蛋白结构和结构域正确
但 contig 较短、邻域缺失或 MAG 不完整
```

### C 级：低可信或仅相关

```text
只有单个非特异基因
或只有泛注释的 cytochrome / porin / pilA / fmnB
```

建议写成：

```text
EET-related candidate
```

而不是直接写“具有 EET 功能”。

---

## 9. 最终推荐策略

```text
1. MEGAHIT 组装
2. Prodigal 预测蛋白
3. FeGenie 初筛 Fe 功能
4. EET 基因家族专用 BLAST/HMM 并行筛选
5. InterProScan、CXXCH、SignalP、膜拓扑检查
6. 基因邻域和全基因组通路背景检查
7. MAG 分箱和物种归属
8. Reads 回帖和丰度计算
9. 按 Fe-EET、非 Fe-EET、Fe 非 EET、不确定分类
10. 按 A/B/C 可信度输出
```
