# EET 基因家族 BLAST 扩展、候选筛选与 HMM 建库

## 1. 正确思路

不是：

```text
种子 → BLAST → 取前 5 条 → 建 HMM
```

而是：

```text
实验验证或高可信种子
        ↓
每个基因家族分别 BLASTP
        ↓
返回 200–500 条候选
        ↓
长度、覆盖度、结构域、基序、定位、邻域检查
        ↓
每个物种通常保留 1 条
        ↓
得到 10–50 条多样化高可信序列
        ↓
MMseqs2 去冗余
        ↓
MAFFT 多序列比对
        ↓
trimAl 修剪
        ↓
hmmbuild
        ↓
正样本、近缘同源和无关负样本测试
```

---

## 2. 第一轮 BLASTP 的目的

第一轮用于建立准确的初级 HMM，宁可少一些，也不要混入错误家族。

优先数据库：

```text
Reference proteins（refseq_protein）
```

初级 HMM 建好并验证后，再用 `nr` 扩展远缘序列。

---

## 3. 推荐统一 BLASTP 参数

```bash
blastp \
  -query mtrA_seed.faa \
  -db refseq_protein \
  -task blastp \
  -evalue 1e-10 \
  -matrix BLOSUM62 \
  -word_size 3 \
  -gapopen 11 \
  -gapextend 1 \
  -comp_based_stats 2 \
  -seg yes \
  -max_target_seqs 500 \
  -max_hsps 1 \
  -num_threads 16 \
  -outfmt "6 qseqid sacc pident length qlen slen qstart qend sstart send evalue bitscore qcovs staxids sscinames stitle" \
  -out mtrA_vs_refseq.tsv
```

输出列：

```text
qseqid
sacc
pident
length
qlen
slen
qstart
qend
sstart
send
evalue
bitscore
qcovs
staxids
sscinames
stitle
```

---

## 4. 第一轮严格筛选

推荐起始条件：

```text
E-value ≤ 1e-20
query coverage ≥ 70%
subject coverage ≥ 70%
identity ≥ 30%
目标长度约为种子长度的 70%–130%
```

计算 subject coverage：

```bash
awk -F'\t' 'BEGIN{OFS="\t"}
{
    scov=100*$4/$6
    if($11<=1e-20 && $13>=70 && scov>=70 && $3>=30)
        print $0,scov
}' mtrA_vs_refseq.tsv \
> mtrA_high_confidence.tsv
```

如果不足 10 条，可逐步放宽到：

```text
E-value ≤ 1e-10
query coverage ≥ 60%
subject coverage ≥ 60%
identity ≥ 25%
```

这些是建库初筛条件，不是功能证明的绝对阈值。

---

## 5. 不同蛋白家族的筛选侧重点

### 5.1 MtrA/MtoA/PioA/DmsE

可用较统一的阈值找候选：

```text
E-value ≤ 1e-10
qcov ≥ 60%
scov ≥ 60%
identity ≥ 25%
```

但 BLAST 只能确定它们属于近缘大类，最终分类依赖邻域：

```text
mtrB – 候选 – mtrC    → MtrA
mtoB – 候选 – mtoD    → MtoA
pioB – 候选 – pioC    → PioA
dmsF – 候选 – dmsAB   → DmsE
```

### 5.2 MtrC/OmcA/MtrF/OmcS/OmcZ

这些大型多血红素蛋白差异较大，可稍微放宽：

```text
E-value ≤ 1e-5
qcov ≥ 50%
scov ≥ 50%
identity ≥ 20%
```

同时检查：

```text
蛋白长度
CXXCH 数量和排列
信号肽
结构域
邻域
系统发育树
```

### 5.3 MtrB/PioB/MtoB/Omb 类孔道蛋白

建议：

```text
E-value ≤ 1e-10
qcov ≥ 60%
scov ≥ 60%
identity ≥ 25%
```

必须结合相邻多血红素细胞色素判断。

### 5.4 CymA/ImcH/CbcL

近缘膜结合细胞色素很多，第一轮建议严格：

```text
E-value ≤ 1e-20
qcov ≥ 70%
scov ≥ 70%
identity ≥ 30%
```

还需检查膜锚定和通路背景。

### 5.5 Cyc2

家族较多样：

```text
E-value ≤ 1e-5
qcov ≥ 50%
scov ≥ 50%
identity ≥ 20%
```

必须检查其特征架构和宿主铁氧化背景。

### 5.6 FmnB/PplA/PioC/Rus

初步可用：

```text
E-value ≤ 1e-10
qcov ≥ 60%
scov ≥ 60%
identity ≥ 25%
```

---

## 6. 为什么不能只取 BLAST 前 5 条

BLAST 前 5 条通常可能是同一物种或同一属的不同菌株：

```text
99%–100% 一致
功能信息重复
系统发育覆盖很窄
```

这会让 HMM 只会识别非常接近种子的蛋白。

建议：

```text
同一物种：通常保留 1 条
同一属：保留 2–5 条不同分支
不同属：尽量覆盖
优先 RefSeq 完整蛋白
剔除 partial、fragment、大量 X 和长度异常
```

每个家族的推荐高可信序列数：

| 阶段 | 数量 |
|---|---:|
| 最低探索性 HMM | 5–10 |
| 初级 HMM 推荐 | 10–30 |
| 较稳定 HMM | 30–100 |
| 高多样性家族 | 50–200 条去冗余序列 |

---

## 7. 从 BLAST 数据库提取候选蛋白

```bash
cut -f2 mtrA_high_confidence.tsv |
sort -u > mtrA_accessions.txt
```

```bash
blastdbcmd \
  -db refseq_protein \
  -entry_batch mtrA_accessions.txt \
  -out mtrA_candidates.faa
```

检查：

```bash
grep -c "^>" mtrA_candidates.faa
seqkit stats mtrA_candidates.faa
```

---

## 8. 建立三个候选集合

### A 级：高可信训练集

```text
完整蛋白
+ 结构域正确
+ 基序/拓扑正确
+ 邻域或通路背景明确
```

保存为：

```text
mtrA_verified_A.faa
```

### B 级：待定集合

```text
蛋白本身正确
但 contig 太短或邻域不完整
```

保存为：

```text
mtrA_uncertain_B.faa
```

### C 级：近缘非目标集合

```text
MtoA
PioA
DmsE
MtrD
CctA
其他近缘多血红素蛋白
```

保存为：

```text
mtrA_close_homologs_C.faa
```

C 级不要直接删除，后面用来测试 HMM 特异性。

---

## 9. 去冗余

```bash
mmseqs easy-cluster \
  mtrA_verified_A.faa \
  mtrA_cluster \
  tmp_mtrA \
  --min-seq-id 0.9 \
  -c 0.8 \
  --cov-mode 0
```

第一版可使用：

```text
90% identity
80% coverage
```

如果仍有大量相似序列，可进一步按 80% 聚类。

---

## 10. 多序列比对

```bash
mafft \
  --auto \
  mtrA_cluster_rep_seq.fasta \
  > mtrA.aln.faa
```

检查比对时重点看：

- 是否有大量异常长插入
- 是否有明显截短序列
- 关键 CXXCH 或其他保守位点是否合理对齐
- 是否有一小群明显与其他序列不一致

---

## 11. 修剪比对

```bash
trimal \
  -in mtrA.aln.faa \
  -out mtrA.trim.aln.faa \
  -automated1
```

不要过度修剪，把家族真实的可变区全部删掉。

---

## 12. 建立 HMM

```bash
hmmbuild \
  mtrA.hmm \
  mtrA.trim.aln.faa
```

查看：

```bash
hmmstat mtrA.hmm
```

多个家族分别建立：

```text
mtrA.hmm
mtrB.hmm
mtrC.hmm
omcA.hmm
cymA.hmm
omcS.hmm
omcZ.hmm
pioA.hmm
mtoA.hmm
cyc2.hmm
pplA.hmm
fmnB.hmm
```

---

## 13. 初级 HMM 的测试

准备：

```text
test/
├── positive.faa
├── close_homologs.faa
└── unrelated_negative.faa
```

运行：

```bash
hmmsearch \
  --tblout mtrA_positive.tbl \
  mtrA.hmm \
  test/positive.faa

hmmsearch \
  --tblout mtrA_close.tbl \
  mtrA.hmm \
  test/close_homologs.faa

hmmsearch \
  --tblout mtrA_negative.tbl \
  mtrA.hmm \
  test/unrelated_negative.faa
```

需要确认：

```text
真正 MtrA 得分整体较高
近缘 MtoA/PioA/DmsE 是否也高分
无关蛋白是否出现明显命中
```

如果 MtrA 与 MtoA/PioA/DmsE 无法通过 HMM score 分离，应先注释为：

```text
MtrA/MtoA/PioA/DmsE-family decaheme cytochrome
```

再通过邻域分类，不能强行写成 MtrA。

---

## 14. 第二轮远缘扩展

初级 HMM 稳定后再：

```text
使用 nr 或更大的蛋白数据库
放宽到 E-value ≤ 1e-5
qcov/scov ≥ 50%
identity ≥ 20%
```

第二轮候选不能直接加入训练集，必须重新经过：

```text
HMM 复核
结构域复核
邻域复核
系统发育树复核
```
